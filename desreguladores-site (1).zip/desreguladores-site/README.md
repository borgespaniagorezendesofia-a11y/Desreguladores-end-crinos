# Ciência em Foco — Desreguladores endócrinos em produtos infantis

Projeto inicial de site responsivo em React + Vite, com seção educativa, busca, quiz interativo, fontes e painel de edição. O projeto pode ser publicado na Vercel e usa Supabase para autenticação e conteúdo compartilhado.

## O que já está incluído
- Página pública responsiva em português.
- Seções de introdução, produtos/fontes de exposição, quiz, pesquisa e referências.
- Busca na seção de produtos e feedback de resposta do quiz.
- Painel visual para editar os textos principais.
- Integração opcional com Supabase para autenticação e salvamento compartilhado.
- Arquivo `supabase-schema.sql` com as tabelas e políticas de acesso.

## Rodar localmente
1. Instale Node.js LTS: https://nodejs.org/
2. Descompacte o projeto e abra a pasta em um terminal.
3. Execute `npm install`.
4. Copie `.env.example` para `.env.local` e preencha as credenciais públicas do Supabase.
5. Execute `npm run dev` e abra o endereço local mostrado no terminal.

Sem credenciais do Supabase, o site abre em modo de demonstração. Nesse modo, as alterações do editor ficam somente no navegador atual e não são compartilhadas com outros visitantes. Não use esse modo como painel administrativo de um site publicado.

## Ativar o painel seguro e o salvamento online
1. Crie um projeto em https://supabase.com/.
2. No SQL Editor do Supabase, execute todo o conteúdo de `supabase-schema.sql`.
3. Em Authentication > Users, crie o usuário que será administrador e confirme o e-mail conforme as configurações escolhidas.
4. Copie o UUID desse usuário e execute a instrução comentada no final do SQL para adicioná-lo a `site_admins`.
5. Em Project Settings > API (ou Connect), copie a Project URL e a chave pública/anon (publishable/anon). Coloque os valores em `.env.local` como `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`.
6. Nunca use a `service_role` key no navegador ou em variáveis `VITE_`.
7. Para Vercel, importe o repositório GitHub e adicione as mesmas duas variáveis em Project Settings > Environment Variables; depois faça um novo deploy.

## Publicar pela Vercel
1. Crie um repositório novo no GitHub, por exemplo `ciencia-em-foco-desreguladores`.
2. Envie todos os arquivos desta pasta para a raiz do repositório (não envie `node_modules` nem `.env.local`).
3. Na Vercel, selecione Add New > Project e importe esse repositório.
4. A Vercel detecta Vite. Comando de build: `npm run build`; diretório de saída: `dist`.
5. Configure as variáveis de ambiente do Supabase antes do deploy final.

## Limites da versão inicial
- O painel atual edita os textos principais; a edição visual de cartões, produtos e referências pode ser ampliada na próxima etapa.
- O quiz é educativo e tem uma pergunta inicial; revise e amplie com base nas referências aprovadas pela equipe.
- O conteúdo científico é um rascunho informativo. Verifique as referências e valide afirmações específicas antes da publicação.
- O site não foi publicado automaticamente. Para colocar no ar, é preciso criar/importar o repositório e configurar a hospedagem e o Supabase.
