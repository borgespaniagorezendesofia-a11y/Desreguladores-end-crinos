import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import { Activity, ArrowDown, ArrowRight, BookOpen, Check, ChevronDown, CircleHelp, FlaskConical, HeartPulse, Leaf, LockKeyhole, Menu, Microscope, Search, ShieldCheck, Sparkles, X } from 'lucide-react';
import './styles.css';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = supabaseUrl && supabaseAnonKey && !supabaseUrl.includes('SEU-PROJETO') ? createClient(supabaseUrl, supabaseAnonKey) : null;

const defaultContent = {
  eyebrow: 'CIÊNCIA PARA CUIDAR MELHOR',
  title: 'Pequenos hábitos.\nGrandes questões.',
  subtitle: 'O que a ciência investiga sobre os desreguladores endócrinos e os produtos usados na infância?',
  introTitle: 'A ciência começa com boas perguntas.',
  introText: 'O sistema endócrino ajuda a regular funções importantes do organismo por meio dos hormônios. Algumas substâncias presentes no ambiente podem interferir nesse sistema; por isso, pesquisadores investigam onde elas aparecem, como ocorre a exposição e quais efeitos podem estar associados a ela.',
  cards: [
    { number: '01', title: 'Entenda o sistema endócrino', text: 'Conheça os hormônios e como eles participam do crescimento e do desenvolvimento.', icon: 'activity' },
    { number: '02', title: 'Observe os produtos do dia a dia', text: 'Descubra quais materiais e ingredientes são estudados pela pesquisa científica.', icon: 'flask' },
    { number: '03', title: 'Consulte as evidências', text: 'Aprenda a diferenciar evidências, hipóteses, riscos e informações sem comprovação.', icon: 'book' }
  ],
  substancesTitle: 'Onde a pesquisa olha?',
  substancesText: 'A presença de uma substância e o risco associado dependem da composição do produto, da dose, da via e da duração da exposição. Nem todo produto contém as substâncias citadas abaixo.',
  products: [
    { name: 'Cosméticos e cuidados pessoais', examples: 'Loções, fragrâncias, shampoos e esmaltes', note: 'Pesquisas avaliam ingredientes específicos, como alguns ftalatos e parabenos, conforme a formulação e a regulamentação aplicável.', tag: 'Composição varia' },
    { name: 'Plásticos e embalagens', examples: 'Recipientes, brinquedos e embalagens de alimentos', note: 'Alguns bisfenóis e ftalatos são estudados por sua possível atividade endócrina e pelas condições em que podem migrar de materiais.', tag: 'Depende do material' },
    { name: 'Produtos de uso doméstico', examples: 'Determinados tecidos, revestimentos e produtos de limpeza', note: 'A investigação científica considera substâncias específicas, formas de contato e frequência de exposição.', tag: 'Avaliar caso a caso' }
  ],
  safetyTitle: 'Informação sem alarmismo.',
  safetyText: 'Encontrar o nome de uma substância em um estudo não significa que todo produto que a contém causará dano. A avaliação científica considera a qualidade das evidências, a quantidade, a exposição e a etapa do desenvolvimento.',
  quizTitle: 'Mito ou conhecimento?',
  quizText: 'Teste o que você aprendeu com uma pergunta rápida.',
  quizQuestion: 'Todo produto infantil que contém uma substância investigada como possível desregulador endócrino causa necessariamente um efeito prejudicial?',
  quizOptions: ['Sim, qualquer presença causa dano.', 'Não. É preciso considerar evidências, dose e condições de exposição.', 'Não existe pesquisa científica sobre o tema.'],
  quizCorrect: 1,
  quizExplanation: 'A avaliação de risco depende de vários fatores, incluindo a substância, a dose, a via e o tempo de exposição, além da qualidade das evidências científicas.',
  researchTitle: 'Conheça a pesquisa',
  researchText: 'Este projeto busca ampliar a compreensão sobre desreguladores endócrinos em produtos infantis, discutir a comunicação científica e identificar dúvidas de pais, responsáveis e adolescentes.',
  sources: [
    { title: 'Organização Mundial da Saúde (OMS)', detail: 'Endocrine disruptors and health', url: 'https://www.who.int/health-topics/chemical-safety' },
    { title: 'Endocrine Society', detail: 'Endocrine-disrupting chemicals', url: 'https://www.endocrine.org/topics/edc' },
    { title: 'ANVISA', detail: 'Cosméticos e produtos de higiene pessoal', url: 'https://www.gov.br/anvisa/pt-br/assuntos/cosmeticos' }
  ],
  footer: 'Um projeto de divulgação científica sobre saúde, infância e ambiente.'
};

const iconMap = { activity: Activity, flask: FlaskConical, book: BookOpen };
function App() {
  const [content, setContent] = useState(defaultContent);
  const [loading, setLoading] = useState(true);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [quizChoice, setQuizChoice] = useState(null);
  const [adminOpen, setAdminOpen] = useState(false);
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [session, setSession] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [draft, setDraft] = useState(defaultContent);
  const [status, setStatus] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    let mounted = true;
    async function load() {
      if (supabase) {
        const { data } = await supabase.from('site_content').select('content').eq('id', 1).maybeSingle();
        if (mounted && data?.content) setContent({ ...defaultContent, ...data.content });
        const { data: auth } = await supabase.auth.getSession();
        if (mounted) setSession(auth.session);
        if (auth.session) await checkAdmin(auth.session.user.id);
        const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
          setSession(nextSession);
          if (nextSession) checkAdmin(nextSession.user.id); else setIsAdmin(false);
        });
        setLoading(false);
        return () => listener.subscription.unsubscribe();
      }
      const local = localStorage.getItem('edc-demo-content');
      if (mounted && local) { try { setContent({ ...defaultContent, ...JSON.parse(local) }); } catch {} }
      setLoading(false);
    }
    let cleanup;
    load().then(fn => { cleanup = fn; });
    return () => { mounted = false; if (cleanup) cleanup(); };
  }, []);

  async function checkAdmin(userId) {
    if (!supabase) return;
    const { data } = await supabase.from('site_admins').select('user_id').eq('user_id', userId).maybeSingle();
    setIsAdmin(Boolean(data));
  }
  const filteredProducts = useMemo(() => content.products.filter(p => `${p.name} ${p.examples} ${p.note}`.toLowerCase().includes(searchTerm.toLowerCase())), [content.products, searchTerm]);
  function openEditor() { setDraft(JSON.parse(JSON.stringify(content))); setStatus(''); setAdminOpen(true); }
  async function login(e) {
    e.preventDefault(); setStatus('Verificando acesso…');
    if (!supabase) { setStatus('Para ativar o acesso administrativo, configure o Supabase seguindo o README. O modo de demonstração não oferece login seguro.'); return; }
    const { data, error } = await supabase.auth.signInWithPassword({ email: adminEmail, password: adminPassword });
    if (error) { setStatus('Não foi possível entrar. Confira o e-mail e a senha.'); return; }
    await checkAdmin(data.user.id);
    setSession(data.session);
    const { data: admin } = await supabase.from('site_admins').select('user_id').eq('user_id', data.user.id).maybeSingle();
    if (admin) { setIsAdmin(true); setDraft(JSON.parse(JSON.stringify(content))); setStatus(''); }
    else { await supabase.auth.signOut(); setStatus('Esta conta não está autorizada a editar o site.'); }
  }
  async function saveContent(e) {
    e.preventDefault(); setStatus('Salvando…');
    if (!supabase) {
      localStorage.setItem('edc-demo-content', JSON.stringify(draft)); setContent(draft); setStatus('Salvo apenas neste navegador (modo de demonstração). Configure o banco de dados para publicar alterações para todos.'); return;
    }
    const { error } = await supabase.from('site_content').upsert({ id: 1, content: draft });
    if (error) { setStatus('Não foi possível salvar. Confira as permissões e a configuração do banco.'); return; }
    setContent(draft); setStatus('Alterações salvas e publicadas!');
  }
  async function logout() { if (supabase) await supabase.auth.signOut(); setSession(null); setIsAdmin(false); setStatus('Você saiu do painel.'); }
  function updateDraft(key, value) { setDraft(prev => ({ ...prev, [key]: value })); }

  return <>
    <header className="topbar"><a className="brand" href="#inicio" aria-label="Página inicial"><span className="brand-mark"><Microscope size={21}/></span><span>CIÊNCIA<span className="brand-light">EM FOCO</span></span></a>
      <button className="mobile-toggle" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Abrir menu">{mobileMenu ? <X/> : <Menu/>}</button>
      <nav className={mobileMenu ? 'nav nav-open' : 'nav'}><a href="#entenda" onClick={() => setMobileMenu(false)}>Entenda</a><a href="#produtos" onClick={() => setMobileMenu(false)}>No dia a dia</a><a href="#quiz" onClick={() => setMobileMenu(false)}>Quiz</a><a href="#pesquisa" onClick={() => setMobileMenu(false)}>A pesquisa</a><button className="admin-link" onClick={openEditor}><LockKeyhole size={15}/> Área da equipe</button></nav>
    </header>
    <main>
      <section className="hero" id="inicio"><div className="hero-text"><div className="eyebrow"><span className="eyebrow-dot"/>{content.eyebrow}</div><h1>{content.title.split('\n').map((line, i) => <React.Fragment key={i}>{i > 0 && <br/>}{line}</React.Fragment>)}</h1><p className="hero-subtitle">{content.subtitle}</p><div className="hero-actions"><a className="button button-dark" href="#entenda">Explore o tema <ArrowRight size={17}/></a><a className="text-link" href="#pesquisa">Sobre o projeto <ArrowDown size={16}/></a></div><div className="hero-note"><span className="note-icon"><ShieldCheck size={19}/></span><span>Informação baseada em ciência, com linguagem acessível e sem alarmismo.</span></div></div>
        <div className="hero-art" aria-label="Ilustração abstrata de ciência e saúde"><div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/><div className="art-sun"><Sparkles size={30}/></div><div className="art-leaf leaf-one"><Leaf size={82}/></div><div className="art-leaf leaf-two"><Leaf size={55}/></div><div className="art-pill pill-one"/><div className="art-pill pill-two"/><div className="art-label label-one">CIÊNCIA <span>+</span> CUIDADO</div><div className="art-label label-two"><HeartPulse size={15}/> SAÚDE INFANTIL</div><div className="art-center"><div className="center-ring"><Activity size={49}/></div><span>O que sabemos?</span></div><span className="art-star star-one">✳</span><span className="art-star star-two">✳</span></div>
      </section>
      <section className="intro section-wrap" id="entenda"><div className="section-kicker">01 / PRIMEIROS PASSOS</div><div className="intro-grid"><h2>{content.introTitle}</h2><p>{content.introText}</p></div><div className="feature-grid">{content.cards.map((card, i) => { const Icon = iconMap[card.icon] || CircleHelp; return <article className="feature-card" key={card.number || i}><div className="feature-top"><span>{card.number || `0${i + 1}`}</span><span className="feature-icon"><Icon size={21}/></span></div><h3>{card.title}</h3><p>{card.text}</p><a href={i === 1 ? '#produtos' : i === 2 ? '#fontes' : '#pesquisa'} aria-label={`Saiba mais: ${card.title}`}><ArrowRight size={19}/></a></article>; })}</div></section>
      <section className="products-section" id="produtos"><div className="section-wrap"><div className="section-kicker">02 / NO DIA A DIA</div><div className="section-heading"><div><h2>{content.substancesTitle}</h2><p>{content.substancesText}</p></div><div className="searchbox"><Search size={17}/><input value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Buscar por produto..." aria-label="Buscar produtos"/></div></div><div className="product-grid">{filteredProducts.map((product, i) => <article className="product-card" key={product.name}><div className={`product-illustration illustration-${i % 3}`}><span className="product-index">0{i + 1}</span>{i === 0 ? <div className="bottle-scene"><div className="bottle bottle-tall"/><div className="bottle bottle-short"/><div className="jar"/></div> : i === 1 ? <div className="plastic-scene"><div className="plastic-block block-one"/><div className="plastic-block block-two"/><div className="plastic-block block-three"/></div> : <div className="home-scene"><div className="home-sun"/><div className="home-shape"/><div className="home-leaf"><Leaf size={52}/></div></div>}</div><div className="product-body"><span className="tag">{product.tag}</span><h3>{product.name}</h3><p className="product-examples">{product.examples}</p><p>{product.note}</p><details><summary>O que observar? <ChevronDown size={15}/></summary><p>Leia os rótulos, consulte fontes oficiais e não conclua que existe risco apenas pelo nome de um ingrediente. Em caso de dúvida, procure orientações de órgãos reguladores e profissionais qualificados.</p></details></div></article>)}</div>{filteredProducts.length === 0 && <p className="empty-state">Nenhum item encontrado. Tente outro termo.</p>}</div></section>
      <section className="safety-band"><div className="safety-icon"><ShieldCheck size={29}/></div><div><div className="section-kicker">UM LEMBRETE IMPORTANTE</div><h2>{content.safetyTitle}</h2><p>{content.safetyText}</p></div></section>
      <section className="quiz-section section-wrap" id="quiz"><div className="quiz-copy"><div className="section-kicker">03 / APRENDA TESTANDO</div><h2>{content.quizTitle}</h2><p>{content.quizText}</p><div className="quiz-decoration"><CircleHelp size={25}/><span>Curiosidade também é ciência.</span></div></div><div className="quiz-card"><div className="quiz-card-top"><span>QUIZ RÁPIDO</span><span>1 PERGUNTA</span></div><h3>{content.quizQuestion}</h3><div className="quiz-options">{content.quizOptions.map((option, i) => <button key={option} onClick={() => setQuizChoice(i)} className={`quiz-option ${quizChoice === i ? 'selected' : ''} ${quizChoice !== null && i === Number(content.quizCorrect) ? 'correct' : ''}`}><span className="option-letter">{String.fromCharCode(65 + i)}</span><span>{option}</span>{quizChoice !== null && i === Number(content.quizCorrect) && <Check size={17}/>}</button>)}</div>{quizChoice !== null && <div className={quizChoice === Number(content.quizCorrect) ? 'quiz-feedback good' : 'quiz-feedback'}><strong>{quizChoice === Number(content.quizCorrect) ? 'Isso mesmo!' : 'Vamos pensar mais um pouco.'}</strong><p>{content.quizExplanation}</p><button onClick={() => setQuizChoice(null)}>Tentar novamente</button></div>}</div></section>
      <section className="research-section" id="pesquisa"><div className="research-inner"><div className="research-symbol"><Microscope size={37}/><span>INVESTIGAR<br/>PARA INFORMAR</span></div><div className="research-content"><div className="section-kicker">04 / SOBRE O PROJETO</div><h2>{content.researchTitle}</h2><p>{content.researchText}</p><a className="button button-light" href="#fontes">Conheça as fontes <ArrowRight size={17}/></a></div><div className="research-stamp"><span>PERGUNTAR</span><Sparkles size={23}/><span>APRENDER</span></div></div></section>
      <section className="sources section-wrap" id="fontes"><div className="section-kicker">05 / PARA CONTINUAR EXPLORANDO</div><div className="sources-heading"><h2>Fontes confiáveis.<br/><span>Conhecimento compartilhado.</span></h2><p>Use referências institucionais e científicas para aprofundar a leitura e verificar informações.</p></div><div className="source-list">{content.sources.map((source, i) => <a className="source-item" key={source.title} href={source.url} target="_blank" rel="noreferrer"><span className="source-number">0{i + 1}</span><span className="source-title"><strong>{source.title}</strong><small>{source.detail}</small></span><ArrowRight size={19}/></a>)}</div><p className="source-disclaimer">Esta página é um material educativo e não substitui orientações médicas ou regulatórias. Os conteúdos devem ser atualizados conforme novas evidências e normas.</p></section>
    </main>
    <footer className="footer"><a className="brand brand-footer" href="#inicio"><span className="brand-mark"><Microscope size={20}/></span><span>CIÊNCIA<span className="brand-light">EM FOCO</span></span></a><p>{content.footer}</p><button onClick={openEditor} className="footer-admin"><LockKeyhole size={14}/> Área da equipe</button><span className="copyright">© {new Date().getFullYear()} · Divulgação científica</span></footer>
    {adminOpen && <div className="modal-backdrop" role="presentation" onMouseDown={e => { if (e.target === e.currentTarget) setAdminOpen(false); }}><section className="admin-modal" role="dialog" aria-modal="true" aria-labelledby="admin-title"><div className="admin-modal-head"><div><span className="section-kicker">ÁREA RESTRITA</span><h2 id="admin-title">Painel de conteúdo</h2></div><button className="icon-button" onClick={() => setAdminOpen(false)} aria-label="Fechar"><X/></button></div>
      {!supabase && <div className="setup-warning"><strong>Modo de demonstração</strong><p>O site está pronto para personalização visual, mas o login seguro e o salvamento online exigem a configuração do Supabase. O salvamento local abaixo funciona apenas neste navegador.</p></div>}
      {!isAdmin ? <form className="admin-login" onSubmit={login}><p>Entre com a conta autorizada para editar os textos e as seções do site.</p><label>E-mail<input type="email" value={adminEmail} onChange={e => setAdminEmail(e.target.value)} required placeholder="voce@exemplo.com"/></label><label>Senha<input type="password" value={adminPassword} onChange={e => setAdminPassword(e.target.value)} required placeholder="Sua senha"/></label><button className="button button-dark" type="submit">Entrar no painel <ArrowRight size={16}/></button>{!supabase && <button className="demo-button" type="button" onClick={() => { setIsAdmin(true); setDraft(JSON.parse(JSON.stringify(content))); setStatus('Demonstração: as alterações serão salvas apenas neste navegador.'); }}>Experimentar editor de demonstração</button>}</form> : <form className="admin-editor" onSubmit={saveContent}><div className="editor-toolbar"><p>Edite os campos abaixo e salve as alterações.</p>{supabase && <button type="button" className="demo-button" onClick={logout}>Sair</button>}</div><label>Chamada superior<input value={draft.eyebrow} onChange={e => updateDraft('eyebrow', e.target.value)}/></label><label>Título principal<textarea rows="2" value={draft.title} onChange={e => updateDraft('title', e.target.value)}/></label><label>Subtítulo<textarea rows="2" value={draft.subtitle} onChange={e => updateDraft('subtitle', e.target.value)}/></label><label>Título da introdução<input value={draft.introTitle} onChange={e => updateDraft('introTitle', e.target.value)}/></label><label>Texto da introdução<textarea rows="4" value={draft.introText} onChange={e => updateDraft('introText', e.target.value)}/></label><label>Título da seção de produtos<input value={draft.substancesTitle} onChange={e => updateDraft('substancesTitle', e.target.value)}/></label><label>Explicação da seção<textarea rows="3" value={draft.substancesText} onChange={e => updateDraft('substancesText', e.target.value)}/></label><label>Título do quiz<input value={draft.quizTitle} onChange={e => updateDraft('quizTitle', e.target.value)}/></label><label>Pergunta do quiz<textarea rows="3" value={draft.quizQuestion} onChange={e => updateDraft('quizQuestion', e.target.value)}/></label><label>Título da pesquisa<input value={draft.researchTitle} onChange={e => updateDraft('researchTitle', e.target.value)}/></label><label>Texto sobre a pesquisa<textarea rows="4" value={draft.researchText} onChange={e => updateDraft('researchText', e.target.value)}/></label><label>Texto do rodapé<input value={draft.footer} onChange={e => updateDraft('footer', e.target.value)}/></label><button className="button button-dark save-button" type="submit">Salvar alterações <Check size={17}/></button></form>}
      {status && <div className="status-message" role="status">{status}</div>}<p className="admin-footnote">Dica: revise as informações científicas e as referências antes de publicar alterações.</p></section></div>}
    {loading && <div className="loading-strip">Carregando conteúdo…</div>}
  </>;
}

createRoot(document.getElementById('root')).render(<React.StrictMode><App/></React.StrictMode>);
