-- Execute este SQL no SQL Editor do seu projeto Supabase.
-- O conteúdo público pode ser lido por qualquer visitante; somente usuários listados em site_admins podem alterá-lo.

create table if not exists public.site_content (
  id integer primary key check (id = 1),
  content jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.site_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.site_content enable row level security;
alter table public.site_admins enable row level security;

drop policy if exists "Public can read site content" on public.site_content;
create policy "Public can read site content" on public.site_content
  for select using (true);

drop policy if exists "Admins can update site content" on public.site_content;
create policy "Admins can update site content" on public.site_content
  for update using (exists (select 1 from public.site_admins a where a.user_id = auth.uid()))
  with check (exists (select 1 from public.site_admins a where a.user_id = auth.uid()));

drop policy if exists "Admins can insert site content" on public.site_content;
create policy "Admins can insert site content" on public.site_content
  for insert with check (exists (select 1 from public.site_admins a where a.user_id = auth.uid()));

drop policy if exists "Admins can read their own admin row" on public.site_admins;
create policy "Admins can read their own admin row" on public.site_admins
  for select using (user_id = auth.uid());

insert into public.site_content (id, content)
values (1, '{"eyebrow":"CIÊNCIA PARA CUIDAR MELHOR","title":"Pequenos hábitos.\nGrandes questões."}'::jsonb)
on conflict (id) do nothing;

-- Depois de criar um usuário em Authentication > Users, copie o UUID dele e execute:
-- insert into public.site_admins (user_id) values ('COLE-AQUI-O-UUID-DO-USUARIO');
